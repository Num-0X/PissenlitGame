#include <SDL3/SDL.h>
#include <iostream>
#include "Grid.h"
#include "Entity.h"

const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 800;

int main(int argc, char* argv[])
{
    if (SDL_Init(SDL_INIT_VIDEO) != 0)
    {
        std::cout << "Erreur SDL_Init : " << SDL_GetError() << std::endl;
        return -1;
    }

    SDL_Window* window = SDL_CreateWindow(
        "Grille SDL3",
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        0
    );

    SDL_Renderer* renderer = SDL_CreateRenderer(window, NULL);

    Grid grid;

    // Exemple : un pissenlit + une graine
    grid.placeDandelion(1, 1);
    grid.addSeed(3, 2);

    bool running = true;

    while (running)
    {
        SDL_Event event;

        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_EVENT_QUIT)
                running = false;
        }

        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_RenderClear(renderer);

        // Grille
        for (int r = 0; r < SIZE; r++)
        {
            for (int c = 0; c < SIZE; c++)
            {
                SDL_FRect cell;
                cell.x = c * 120 + 50;
                cell.y = r * 120 + 50;
                cell.w = 120;
                cell.h = 120;

                SDL_SetRenderDrawColor(renderer, 80, 80, 80, 255);
                SDL_RenderRect(renderer, &cell);
            }
        }

        // Entités
        for (auto& e : grid.getEntities())
            e->render(renderer);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
