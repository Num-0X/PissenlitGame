#include "Entity.h"

// Taille d'une cellule de la grille
const int CELL_SIZE = 120;

// Décalage pour centrer la grille dans la fenêtre
const int OFFSET_X = 50;
const int OFFSET_Y = 50;

// Constructeur
Entity::Entity(int x, int y, EntityType t)
{
    gridX = x;
    gridY = y;
    type = t;
}

// Affichage SDL
void Entity::render(SDL_Renderer* renderer)
{
    // Conversion grille → pixels
    float x = gridX * CELL_SIZE + OFFSET_X;
    float y = gridY * CELL_SIZE + OFFSET_Y;

    // ============================
    // PISSENLIT = carré jaune
    // ============================
    if (type == EntityType::PISSENLIT)
    {
        SDL_FRect rect;
        rect.x = x + 20;
        rect.y = y + 20;
        rect.w = 80;
        rect.h = 80;

        SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
        SDL_RenderFillRect(renderer, &rect);
    }

  
    // SEED = petit cercle jaune
  
    else if (type == EntityType::SEED)
    {
        SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);

        int centerX = x + 60;
        int centerY = y + 60;
        int radius = 10;

        // Dessin d'un cercle rempli
        for (int w = -radius; w <= radius; w++)
        {
            for (int h = -radius; h <= radius; h++)
            {
                if ((w*w + h*h) <= radius * radius)
                    SDL_RenderPoint(renderer, centerX + w, centerY + h);
            }
        }
    }
}
