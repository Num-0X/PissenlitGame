#ifndef ENTITY_H
#define ENTITY_H

#include <SDL3/SDL.h>

// Types possibles d'entités dans la grille
enum class EntityType
{
    EMPTY,
    PISSENLIT,
    SEED
};

class Entity
{
private:
    int gridX;          // Colonne dans la grille
    int gridY;          // Ligne dans la grille
    EntityType type;    // Type d'entité

public:
    // Constructeur
    Entity(int x, int y, EntityType t);

    // Getters utilisés par Grid et main
    int getGridX() const { return gridX; }
    int getGridY() const { return gridY; }
    EntityType getType() const { return type; }

    // Méthodes utilitaires
    bool isPissenlit() const { return type == EntityType::PISSENLIT; }
    bool isSeed() const { return type == EntityType::SEED; }

    // Affichage SDL
    void render(SDL_Renderer* renderer);
};

#endif
