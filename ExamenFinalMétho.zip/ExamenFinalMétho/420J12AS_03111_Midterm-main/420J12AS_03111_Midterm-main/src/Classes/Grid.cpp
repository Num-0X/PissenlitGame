#include "Grid.h"

// Vérifie si une case contient déjà une entité
bool Grid::isOccupied(int r, int c) {
    for (auto& e : entities)
        if (e->getGridY() == r && e->getGridX() == c)
            return true;
    return false;
}

// Ajoute un pissenlit
void Grid::placeDandelion(int r, int c) {
    entities.push_back(std::make_unique<Entity>(c, r, EntityType::PISSENLIT));
}

// Ajoute une graine si la case est vide
void Grid::addSeed(int r, int c) {
    if (!isOccupied(r, c))
        entities.push_back(std::make_unique<Entity>(c, r, EntityType::SEED));
}

// Vent vers le nord
void Grid::spreadNorth() {
    std::vector<std::pair<int,int>> newSeeds;

    for (auto& e : entities) {
        if (e->isPissenlit()) {

            int col = e->getGridX();

            for (int k = e->getGridY() - 1; k >= 0; k--) {
                if (!isOccupied(k, col))
                    newSeeds.push_back({k, col});
            }
        }
    }

    for (auto& s : newSeeds)
        addSeed(s.first, s.second);
}

// Vent vers le sud
void Grid::spreadSouth() {
    std::vector<std::pair<int,int>> newSeeds;

    for (auto& e : entities) {
        if (e->isPissenlit()) {

            int col = e->getGridX();

            for (int k = e->getGridY() + 1; k < SIZE; k++) {
                if (!isOccupied(k, col))
                    newSeeds.push_back({k, col});
            }
        }
    }

    for (auto& s : newSeeds)
        addSeed(s.first, s.second);
}

// Vérifie si toute la grille est remplie
bool Grid::isFull() {
    for (int i = 0; i < SIZE; i++)
        for (int j = 0; j < SIZE; j++)
            if (!isOccupied(i, j))
                return false;
    return true;
}
