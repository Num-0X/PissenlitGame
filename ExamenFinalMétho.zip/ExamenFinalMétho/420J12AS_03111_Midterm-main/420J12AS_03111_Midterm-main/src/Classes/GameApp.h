#pragma once
#include <SDL3/SDL.h>
#include <vector>

// Classe principale SDL
class GameApp {
public:
    SDL_Window* Window = nullptr;
    SDL_Renderer* Renderer = nullptr;

    float SampleAverageFPS = 0.0f;

    GameApp();
    ~GameApp();

    void CalculateFPS(float dt);

private:
    std::vector<float> _frame_times;
};