#include "GameApp.h"
#include <numeric>

static const int MAX_SAMPLES = 100;

GameApp::GameApp() {
    SDL_Init(SDL_INIT_VIDEO);

    Window = SDL_CreateWindow("Jeu du Pissenlit", 800, 600, 0);
    Renderer = SDL_CreateRenderer(Window, nullptr);

    SDL_SetRenderVSync(Renderer, true);
}

GameApp::~GameApp() {
    SDL_DestroyRenderer(Renderer);
    SDL_DestroyWindow(Window);
    SDL_Quit();
}

// Calcul FPS moyen
void GameApp::CalculateFPS(float dt) {
    _frame_times.push_back(dt);

    if (_frame_times.size() > MAX_SAMPLES)
        _frame_times.erase(_frame_times.begin());

    float sum = std::accumulate(_frame_times.begin(), _frame_times.end(), 0.0f);
    float avg = sum / _frame_times.size();

    SampleAverageFPS = avg > 0 ? 1.0f / avg : 0;
}