#pragma once
#include <memory>
#include <vector>
#include "Entity.h"

// Taille de la grille
const int SIZE = 5;

class Grid
{
private:
    // Liste dynamique d'entités
    std::vector<std::unique_ptr<Entity>> entities;

public:
    // Vérifie si une case contient déjà une entité
    bool isOccupied(int r, int c);

    // Ajoute un pissenlit
    void placeDandelion(int r, int c);

    // Ajoute une graine si la case est vide
    void addSeed(int r, int c);

    // Propagation du vent
    void spreadNorth();
    void spreadSouth();

    // Vérifie si la grille est pleine
    bool isFull();

    // Accès aux entités pour l'affichage
    const std::vector<std::unique_ptr<Entity>>& getEntities() const { return entities; }
};
